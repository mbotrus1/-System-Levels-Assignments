The two options I could have used to change the permissions are
chown which species options and user group and another 
option would be using chgrp to specify group ownership

to Modify the Hunger Games file I used the pattern replace options for vi

the command is given as follows

:%s/pattern/replace

where pattern is what I want to replace
and replace is the text that I exchange for pattern. 

In this case I replaced Peeta with Maryam. So the command would be

:%s/Peeta/Maryam